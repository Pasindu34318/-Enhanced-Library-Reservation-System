package controller;

import dao.ReservationDAO;
import model.Reservation;
import model.User;

import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/reserveBook")
public class ReservationServlet extends HttpServlet {

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        User user = (User) request.getSession().getAttribute("user");
        if (user == null || !"Student".equals(user.getRole())) {
            response.sendRedirect("login.jsp");
            return;
        }

        int bookId = Integer.parseInt(request.getParameter("bookId"));
        Reservation r = new Reservation();
        r.setStudentName(user.getUsername());
        r.setBookId(bookId);

        ReservationDAO dao = new ReservationDAO();
        dao.addReservation(r);

        response.sendRedirect("searchBook.jsp");
    }
}
