package controller;

import dao.BookDAO;
import model.Book;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.io.InputStream;

@WebServlet("/addBook")
public class BookServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String title = request.getParameter("title");
        String author = request.getParameter("author");
        
        

        if (title == null || author == null || title.trim().isEmpty() || author.trim().isEmpty()) {
            response.sendRedirect("error.jsp");
            return;
        }

        Book book = new Book();
        book.setTitle(title);
        book.setAuthor(author);
        book.setStatus("Available");

        BookDAO dao = new BookDAO();
        dao.addBook(book);

        response.sendRedirect("dashboard.jsp");
    }
}
