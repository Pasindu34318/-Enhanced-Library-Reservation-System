package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import model.Book;

public class DBUtil {
    public static Connection getConnection() {
        Connection con = null;
        try {
            Class.forName("com.mysql.cj.jdbc.Driver"); 
            con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3309/enlibrarydb", "root", ""
            );
        } catch (Exception e) {
            e.printStackTrace();
        }
        return con;
    }

    public void addBook(Book book) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
