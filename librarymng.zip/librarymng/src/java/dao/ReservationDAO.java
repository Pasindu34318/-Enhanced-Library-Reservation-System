package dao;

import model.Reservation;
import java.sql.*;
import java.util.*;
import dao.DBUtil;

public class ReservationDAO {

    public void addReservation(Reservation r) {
        try (Connection con = DBUtil.getConnection()) {
            PreparedStatement ps = con.prepareStatement("INSERT INTO reservations (student_name, book_id, reservation_date) VALUES (?, ?, NOW())");
            ps.setString(1, r.getStudentName());
            ps.setInt(2, r.getBookId());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    
    
    public List<Reservation> getAllReservations() {
        List<Reservation> list = new ArrayList<>();
        try (Connection con = DBUtil.getConnection()) {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT * FROM reservations");
            while (rs.next()) {
                Reservation r = new Reservation();
                r.setId(rs.getInt("id"));
                r.setStudentName(rs.getString("student_name"));
                r.setBookId(rs.getInt("book_id"));
                r.setReservationDate(rs.getDate("reservation_date"));
                list.add(r);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
